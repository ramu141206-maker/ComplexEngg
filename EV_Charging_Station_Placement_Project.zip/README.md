# Optimal EV Charging Station Placement

## Project Overview
This project analyses existing electric vehicle charging station records
and identifies preliminary candidate areas for further investigation.

## Tools Used
- Python
- Pandas
- NumPy
- Matplotlib
- Folium
- Google Colab
- GitHub

## Main Features
- Data cleaning and validation
- Geographic station distribution analysis
- Preliminary candidate location ranking
- Straight-line distance analysis
- Illustrative budget scenario comparison
- Geographic map and planning dashboard

## Limitations
Candidate locations are preliminary geographic suggestions, not verified
installation sites. The dataset may not contain traffic demand, charging
sessions, electricity grid capacity, road-network distance, or real
installation costs. Budget calculations use explicitly stated assumptions.

## Outputs
- Cleaned station data
- Geographic grid summary
- Candidate locations
- Budget comparison
- Coverage summary
- Geographic map
